package client.event;

import client.pages.ModifyingData;
import client.pages.PersonalCenter;

import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class GoEditEvent extends MouseAdapter {
    Object page;
    JFrame frame;
    public GoEditEvent(Object page, JFrame frame) {
        this.page = page;
        this.frame=frame;
    }
    public void mouseClicked(MouseEvent e) {

        if (e.getSource() == page){
            frame.dispose();
            new ModifyingData();
        }



    }
}
