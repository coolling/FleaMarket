package client.event;

import client.pages.ReleaseProduct;
import client.pages.ShoppingCart;

import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class GoReleaseEvent extends MouseAdapter {
    Object page;
    JFrame frame;
    public GoReleaseEvent(Object page, JFrame frame) {
        this.page = page;
        this.frame=frame;
    }
    public void mouseClicked(MouseEvent e) {

        if (e.getSource() == page){
            frame.dispose();
            new ReleaseProduct();
        }



    }
}
