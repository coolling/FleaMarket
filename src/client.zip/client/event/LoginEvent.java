package client.event;

import client.pages.Index;
import client.pages.Mistake;
import client.pages.ProductDetails;
import client.pages.Register;
import client.socket.LoginSocket;
import com.alibaba.fastjson.JSONObject;

import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.*;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class LoginEvent extends MouseAdapter {
    Object login;
    JFrame frame;
    static final int PORT = 6502;

    int port;

    public LoginEvent(Object login, JFrame frame) {
        this.login = login;
        this.frame = frame;
    }



    public void mouseClicked(MouseEvent e) {

        if (e.getSource() == login) {
            try {
                int result = LoginSocket.loginServe();
                if (result == 0) {
                    frame.dispose();
                    new Index();
                } else {
                    frame.dispose();
                    new Mistake();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }

        } else {
            frame.dispose();
            new Register();
        }


    }
}

