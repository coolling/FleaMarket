package client.event;

import client.pages.Index;
import client.pages.PersonalCenter;
import client.pages.Register;

import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class GoCenterEvent extends MouseAdapter {
    Object page;
    JFrame frame;
    public GoCenterEvent(Object page, JFrame frame) {
        this.page = page;
        this.frame=frame;
    }
    public void mouseClicked(MouseEvent e) {

        if (e.getSource() == page){
            frame.dispose();
            new PersonalCenter();
        }



    }
}

