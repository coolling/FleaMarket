package client.event;

public class EditInforEvent {
}
