package client.event;

import client.pages.*;
import com.alibaba.fastjson.JSONObject;

import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Scanner;

public class RegisterEvent extends MouseAdapter {
    Object register;
    JFrame frame;
    public RegisterEvent(Object register, JFrame frame) {
        this.register = register;
        this.frame=frame;
    }

    public void mouseClicked(MouseEvent e) {

        if (e.getSource() == register){
            frame.dispose();
            new RegisterSuccess();
        }else{
            frame.dispose();
            new Login();
        }


    }
}
