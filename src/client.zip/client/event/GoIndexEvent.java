package client.event;

import client.pages.Index;
import client.pages.ShoppingCart;

import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class GoIndexEvent extends MouseAdapter {
    Object page;
    JFrame frame;
    public GoIndexEvent(Object page, JFrame frame) {
        this.page = page;
        this.frame=frame;
    }
    public void mouseClicked(MouseEvent e) {

        if (e.getSource() == page){
            frame.dispose();
            new Index();
        }



    }
}