package client.event;

import client.pages.AddSuccess;
import client.pages.ShoppingCart;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;

public class AddToCartEvent implements ActionListener {
    Object page;
    JFrame frame;
    public AddToCartEvent(Object page, JFrame frame) {
        this.page = page;
        this.frame=frame;
    }
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == page){
            frame.dispose();
            new AddSuccess();
        }



    }
}


