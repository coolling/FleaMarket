package client.event;

public class SearchEvent {
}
