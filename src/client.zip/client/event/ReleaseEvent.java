package client.event;

public class ReleaseEvent {
}
