package client.base;

public class Base {
    static int loginPort=2000;
    static int registerPort = 2001;
    static int changeHeadPort = 2002;
    static int editPort = 2003;
    static int changePassPort = 2004;
    static int checkCarPort = 2200;
    static int releasePort = 2100;
    static int addCarPort=2201;
    static int deleteCarPort=2202;
}
