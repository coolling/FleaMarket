package client.pages;

import client.component.CLabel;
import client.component.ImagePanel;
import client.component.RoundBorder;
import client.event.*;

import javax.swing.*;
import java.awt.*;

public class PersonalCenter extends JFrame {
    String imgUrl = "/WechatIMG12.jpeg";
    String nickName="哒哒哒哒玲";
    String sex = "女";
    String grade="大一";
    String name = "帅大玲" ;
    String major = "软件工程";
    String area = "软件园";
    String telenumber="1111000111";
    public PersonalCenter(){
        super();
        setLayout(null);
        Toolkit toolkit = Toolkit.getDefaultToolkit();//获得默认的底层控件的基本功能
        Dimension screen = toolkit.getScreenSize();
        int x = (screen.width - 1111) / 2;
        int y = (screen.height - 625) / 2;
        setBounds(x, y, 1111, 625);//设置窗口居中
        view();

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        setVisible(true);
    }
    private void view(){
        this.getContentPane().setBackground(Color.white);
        Color color1 = new Color(231, 252, 243);
        JPanel head = new JPanel();
        head.setLayout(null);
        head.setBackground(color1);
        head.setBounds(0, 0, 1111, 75);
        add(head);
        JLabel back = new JLabel("返回首页");
        GoIndexEvent goIndexEvent = new GoIndexEvent(back,this);
        back.addMouseListener(goIndexEvent);
        back.setForeground(new Color(112, 112, 112));//设置JLabel颜色
        back.setFont(new Font("华文宋体", Font.PLAIN, 30));//设置JLabel样式
        JLabel center = new JLabel("个人中心");

        center.setForeground(new Color(141,131,131));
        center.setFont(new Font("华文宋体", Font.PLAIN, 27));
        JLabel modify = new JLabel("编辑个人资料");
        GoEditEvent goEditEvent = new GoEditEvent(modify,this);
        modify.addMouseListener(goEditEvent);
        modify.setForeground(new Color(112, 112, 112));
        modify.setFont(new Font("华文宋体", Font.PLAIN, 30));
        back.setBounds(30, 1, 200, 70);
        center.setBounds(500, 1, 200, 70);
        modify.setBounds(900, 1, 200, 70);
        head.add(back);
        head.add(center);
        head.add(modify);
        JPanel bottom = new JPanel();
        bottom.setBounds(0,495,1111,110);
        bottom.setBackground(new Color(247,248,248));
        add(bottom);
        bottom.setLayout(null);
        ImagePanel car = new ImagePanel("/car.png",true,65);
        bottom.add(car);
        car.setBounds(90,13,65,65);
        ImagePanel record = new ImagePanel("/record.png");
        bottom.add(record);


        ImagePanel add = new ImagePanel("/add.png");
        bottom.add(add);
        record.setBounds(650,15,65,65);
        add.setBounds(370,17,57,57);
        ImagePanel my = new ImagePanel("/my.png");
        bottom.add(my);
        my.setBounds(930,15,65,65);
        JLabel carLable = new JLabel("购物车");

        JLabel addLable = new JLabel("发布商品");
        JLabel myLable = new JLabel("我的商品");
        JLabel recordLable = new JLabel("交易记录");

        Color c1 = new Color(141,131,131);
        carLable.setForeground(c1);
        addLable.setForeground(c1);
        myLable.setForeground(c1);
        recordLable.setForeground(c1);

        bottom.add(carLable);
        bottom.add(addLable);
        bottom.add(myLable);
        bottom.add(recordLable);
        carLable.setBounds(102,83,65,20);
        addLable.setBounds(373,83,65,20);
        recordLable.setBounds(656,83,65,20);
        myLable.setBounds(942,83,65,20);
        CheckRecordEvent checkRecordEvent2 = new CheckRecordEvent(record,this);
        record.addMouseListener(checkRecordEvent2);
        CheckRecordEvent checkRecordEvent = new CheckRecordEvent(recordLable,this);
        recordLable.addMouseListener(checkRecordEvent);
        CheckCartEvevt checkCartEvevt = new CheckCartEvevt(carLable,this);
        carLable.addMouseListener(checkCartEvevt);
        CheckCartEvevt checkCartEvevt2 = new CheckCartEvevt(car,this);
        car.addMouseListener(checkCartEvevt2);


        CheckMyGoodsEvent checkMyGoodsEvent = new CheckMyGoodsEvent(my,this);
        CheckMyGoodsEvent checkMyGoodsEvent2 = new CheckMyGoodsEvent(myLable,this);
        my.addMouseListener(checkMyGoodsEvent);
        myLable.addMouseListener(checkMyGoodsEvent2);
        GoReleaseEvent goReleaseEvent = new GoReleaseEvent(add,this);
        add.addMouseListener(goReleaseEvent);
        GoReleaseEvent goReleaseEvent2 = new GoReleaseEvent(addLable,this);
        addLable.addMouseListener(goReleaseEvent2);
        ImagePanel userHead = new ImagePanel(imgUrl);

        userHead.setBounds(100,120,80,80);
        add(userHead);
        JLabel nicknameLable = new JLabel(nickName);
        JLabel gradeLable = new JLabel("年级： "+grade);
        JLabel areaLable = new JLabel("校区： "+area);
        JLabel majorLable = new JLabel("专业： "+major);
        JLabel sexLable = new JLabel("性别： "+sex);
        JLabel nameLable = new JLabel("姓名： "+name);
        add(nicknameLable);
        add(areaLable);
        add(majorLable);
        add(sexLable);
        add(nameLable);
        add(gradeLable);
        nicknameLable.setBounds(220,150,200,50);
        Font f1= new Font("华文宋体", Font.PLAIN, 35);
        nicknameLable.setFont(f1);
        nicknameLable.setForeground(c1);
        sexLable.setFont(f1);
        nameLable.setFont(f1);
        gradeLable.setFont(f1);
        areaLable.setFont(f1);
        majorLable.setFont(f1);
        sexLable.setForeground(c1);
        nameLable.setForeground(c1);
        gradeLable.setForeground(c1);
        majorLable.setForeground(c1);
        areaLable.setForeground(c1);
        sexLable.setBounds(660,110,500,70);
        gradeLable.setBounds(660,180,500,70);
        majorLable.setBounds(660,250,500,70);
        areaLable.setBounds(660,320,500,70);
        nameLable.setBounds(660,390,500,70);
        JLabel out = new JLabel("  退出登陆");
        add(out);
        out.setBounds(966,433,105,45);
        out.setForeground( new Color(99, 91, 91, 231));
        out.setFont(new Font("华文宋体", Font.PLAIN, 20));
        out.setBorder(new RoundBorder(5,Color.black));
        JLabel tele = new JLabel("call："+telenumber);
        add(tele);
        tele.setBounds(220,195,300,45);
        tele.setForeground( new Color(119, 110, 110, 156));
        tele.setFont(new Font("华文宋体", Font.PLAIN, 20));

    }
    public static void main(String[] args){
        PersonalCenter personalCenter = new PersonalCenter();
    }
}
