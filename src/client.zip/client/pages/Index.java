
package client.pages;

import client.component.ImagePanel;
import client.event.CheckProductEvents;
import client.event.GoCenterEvent;


import javax.swing.*;
import java.awt.*;
import java.net.*;

public class Index extends JFrame {

    JScrollPane productsDiv = new JScrollPane();
    JPanel productdiv = new JPanel();
    String products[][] = {{"sky", "60", "/WechatIMG10.jpeg"},
            {"sky", "60", "/WechatIMG10.jpeg"}, {"beautiful", "100", "/WechatIMG12.jpeg"}, {"sky", "60", "/WechatIMG10.jpeg"},
            {"sky", "60", "/WechatIMG10.jpeg"}, {"sky", "60", "/WechatIMG10.jpeg"},
            {"sky", "60", "/WechatIMG10.jpeg"}, {"beautiful", "100", "/WechatIMG12.jpeg"}, {"beautiful", "100", "/WechatIMG12.jpeg"}, {"beautiful", "100", "/WechatIMG12.jpeg"}};
    int height = products.length % 4 == 0 ? (int) (products.length) / 4 : (int) (products.length) / 4 + 1;

    public Index() {
        super();

        setLayout(null);
        Toolkit toolkit = Toolkit.getDefaultToolkit();//获得默认的底层控件的基本功能
        Dimension screen = toolkit.getScreenSize();
        int x = (screen.width - 1111) / 2;
        int y = (screen.height - 625) / 2;
        setBounds(x, y, 1111, 625);//设置窗口居中
        view();

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        setVisible(true);
    }

    public void view() {
        this.getContentPane().setBackground(Color.white);
        Color color1 = new Color(231, 252, 243);
        JPanel head = new JPanel();
        head.setLayout(null);
        head.setBackground(color1);
        head.setBounds(0, 0, 1111, 75);
        JLabel types = new JLabel("分类");
        types.setForeground(new Color(112, 112, 112));//设置JLabel颜色
        types.setFont(new Font("华文宋体", Font.PLAIN, 33));//设置JLabel样式
        JLabel auction = new JLabel("拍卖会");
        auction.setForeground(new Color(112, 112, 112));
        auction.setFont(new Font("华文宋体", Font.PLAIN, 33));
        JLabel my = new JLabel("个人中心");
        GoCenterEvent goCenterEvent = new GoCenterEvent(my,this);
        my.addMouseListener(goCenterEvent);
        my.setForeground(new Color(112, 112, 112));
        my.setFont(new Font("华文宋体", Font.PLAIN, 33));
        types.setBounds(100, 1, 100, 70);
        auction.setBounds(490, 1, 100, 70);
        my.setBounds(900, 1, 200, 70);
        head.add(types);
        head.add(auction);
        head.add(my);
        add(head);

        TextField search = new TextField(30);
        search.setBounds(200, 120, 550, 35);
        JButton searchBtu = new JButton("search");
        searchBtu.setForeground(new Color(47, 61, 70));
        searchBtu.setBounds(780, 115, 80, 45);
        searchBtu.setBackground(new Color(113, 193, 252));

        // searchBtu.setOpaque(true);
        //searchBtu.setBorderPainted(false);
        searchBtu.setForeground(new Color(47, 61, 70));

        add(searchBtu);
        add(search);
        revalidate();
        productsDiv.setBorder(null);
        productsDiv.setBounds(0, 190, 1111, 430);
        productdiv.setBackground(Color.white);
        productdiv.setLayout(new FlowLayout(FlowLayout.LEFT, 50, 20));
        productsDiv.setViewportView(productdiv);
        productdiv.setPreferredSize(new Dimension(1111, height * 350));
        // productsDiv.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS );
        //productsDiv.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        //productdiv.setLayout(null);
        add(productsDiv);
        showProduct();
    }

    public void showProduct() {
        for (int i = 0; i < products.length; i++) {

            JLabel iconType = new JLabel();


            ImagePanel imgProduct = new ImagePanel(products[i][2]);

            JLabel price = new JLabel("$" + products[i][1]);
            JLabel name = new JLabel(products[i][0]);

            imgProduct.setPreferredSize(new Dimension(205, 210));
            JPanel productPanel = new JPanel();
            CheckProductEvents m = new CheckProductEvents(productPanel, this);
            productPanel.addMouseListener(m);
            productPanel.setPreferredSize(new Dimension(210, 270));
            price.setPreferredSize(new Dimension(210, 30));
            name.setPreferredSize(new Dimension(210, 30));
            productPanel.add(imgProduct);
            productPanel.add(price);
            productPanel.add(name);
            productPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));
            productPanel.setBackground(Color.white);
            productPanel.setBorder(BorderFactory.createEtchedBorder());
            productdiv.add(productPanel);
            // imgProduct.setSize(2000,3000);
            //productdiv.add( imgProduct);
        }
    }

    public static void main(String[] args) throws UnknownHostException {
        Index index = new Index();
        //InetAddress ia2=InetAddress.getByName("DESKTOP-93QCALJ");
        //System.out.println(ia2.getHostAddress());
    }
}
