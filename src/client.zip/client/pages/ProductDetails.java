package client.pages;

import client.component.ImagePanel;
import client.component.RoundBorder;
import client.event.CheckProductEvents;
import client.event.GoIndexEvent;

import javax.swing.*;
import java.awt.*;

public class ProductDetails extends JFrame {
    String productName="sky";
    double productPrice=9999;
    String productDetails="炒鸡美腻！！！！！！炒鸡美腻！！！！！！炒鸡美腻！！！！！！炒鸡美腻！！！！！！";
    String productUrl="/WechatIMG10.jpeg";
    String[][] comments={{"丛丛丛","不错不错"},{"丛丛丛","不错不错"},{"丛丛丛","不错不错"},{"丛丛丛","不错不错"}};
    public ProductDetails(){
        super();

        setLayout(null);
        Toolkit toolkit = Toolkit.getDefaultToolkit();//获得默认的底层控件的基本功能
        Dimension screen = toolkit.getScreenSize();
        int x = (screen.width - 1111) / 2;
        int y = (screen.height - 625) / 2;
        setBounds(x, y, 1111, 625);//设置窗口居中
        view();

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        setVisible(true);
    }
    private void view(){
        this.getContentPane().setBackground(Color.white);//用this.setBackground(Color.white);不行
        Color color1 = new Color(231, 252, 243);
        JPanel head = new JPanel();
        head.setLayout(null);
        head.setBackground(color1);
        head.setBounds(0, 0, 1111, 75);
        add(head);
        JLabel detail = new JLabel("商品详情界面");
        detail.setForeground(new Color(131, 111, 111));
        detail.setFont(new Font("华文宋体", Font.PLAIN, 27));
        detail.setBounds(470, 1, 300, 70);

        JLabel back = new JLabel("返回首页");
        GoIndexEvent goIndexEvent = new GoIndexEvent(back,this);
        back.addMouseListener(goIndexEvent);
        back.setForeground(new Color(131, 111, 111));
        back.setFont(new Font("华文宋体", Font.PLAIN, 27));
        back.setBounds(30, 1, 300, 70);
        head.add(back);
        head.add(detail);
        ImagePanel productImg = new ImagePanel(productUrl);
        productImg.setBounds(120,120,230,285);
        add(productImg);
        JLabel aproductName = new JLabel("名称    "+productName);
        JLabel aproductPrice = new JLabel("价格    ¥"+productPrice);
        JLabel aproductDetail = new JLabel("介绍    ");
        Color c1 = new Color(141,131,131);
        aproductName.setForeground(c1);
        aproductPrice.setForeground(c1);
        aproductDetail.setForeground(c1);
        Font f1= new Font("华文宋体", Font.PLAIN, 32);
        aproductName.setFont(f1);
        aproductPrice.setFont(f1);
        aproductDetail.setFont(f1);
        aproductName.setBounds(520,120,400,50);
        aproductPrice.setBounds(520,190,400,50);
        aproductDetail.setBounds(520,260,400,50);
        add(aproductName);
        add(aproductDetail);
        add(aproductPrice);
        JTextArea detailArea=new JTextArea(productDetails,4,30);
        detailArea.setLineWrap(true);    //设置文本域中的文本为自动换行
        detailArea.setForeground(c1);    //设置字体颜色
        detailArea.setFont(new Font("楷体",Font.BOLD,20));    //修改字体样式
        detailArea.setBackground(new Color(247,248,248));    //设置背景色
        detailArea.setEnabled(false);
        JScrollPane detailScoll=new JScrollPane(detailArea);    //将文本域放入滚动窗口
        add(detailScoll);
        detailScoll.setBounds(620,270,400,80);
        showComment();
        JButton add = new JButton("加入购物车");
        JButton connect = new JButton("联系卖家");
        add(add);
        add(connect);
        add.setBounds(650,375,130,50);
        connect.setBounds(825,375,130,50);
        add.setForeground( new Color(141,131,131));
        connect.setForeground( new Color(141,131,131));
    }
    private void showComment(){
        Color c1 = new Color(141,131,131);
        Color c2 = new Color(157,141,175);
        Font f1= new Font("华文宋体", Font.PLAIN, 20);
        JScrollPane commentsDiv = new JScrollPane();
        JPanel commentdiv = new JPanel();
        for (int i = 0; i < comments.length; i++) {

            JLabel user = new JLabel("用户： "+comments[i][0]);
            JLabel commentText = new JLabel(comments[i][1]);

            user.setForeground(c2);
            commentText.setForeground(c1);
            user.setFont(f1);
            commentText.setFont(f1);
            JPanel commentPanel = new JPanel();
            commentPanel.setPreferredSize(new Dimension(950, 100));
            user.setPreferredSize(new Dimension(210, 30));
            commentText.setPreferredSize(new Dimension(850, 30));
            user.setBounds(20,10,900,40);
            commentText.setBounds(20,50,900,40);

            commentPanel.add(user);
            commentPanel.add(commentText);
            commentPanel.setLayout(null);

            commentPanel.setBackground(Color.white);
            //commentPanel.setBackground(new Color(250,236,240));
            commentPanel.setBorder(new RoundBorder(0,Color.black));
            commentdiv.add( commentPanel);

        }
        commentsDiv.setBorder(null);
        commentsDiv.setBounds(58, 450, 1000, 140);
        commentdiv.setBackground(Color.white);
        commentdiv.setLayout(new FlowLayout(FlowLayout.LEFT, 10,10));
        commentsDiv.setViewportView(commentdiv);
        commentdiv.setPreferredSize(new Dimension(950, comments.length * 110));
        //commentsDiv.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER );
        commentsDiv.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        //productdiv.setLayout(null);
        add(commentsDiv);

    }
    public static void main(String[] args){
        ProductDetails productDetails = new ProductDetails();
    }
}
