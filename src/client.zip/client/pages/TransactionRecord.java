package client.pages;

import client.component.Head;
import client.component.RecordTable;
import client.event.GoCenterEvent;
import client.event.RegisterEvent;

import javax.swing.*;
import java.awt.*;

public class TransactionRecord extends JFrame {
    Object name[] = {"买卖", "商品名称", "商品单价", "商品数量", "时间"};
    Object myGoods[][] = {{"hhh", "5", "ok", "99", "on"},
            {"hhh", "5", "ok", "99", "on"},
            {"hhh", "5", "ok", "99", "on"},
            {"hhh", "5", "ok", "99", "on"},
            {"hhh", "5", "ok", "99", "on"},
            {"hhh", "5", "ok", "99", "on"},
            {"hhh", "5", "ok", "99", "on"},
            {"hhh", "5", "ok", "99", "on"},
            {"hhh", "5", "ok", "99", "on"},
            {"hhh", "5", "ok", "99", "on"},
            {"hhh", "5", "ok", "99", "on"},
            {"hhh", "5", "ok", "99", "on"}};
    public TransactionRecord() {
        super();

        setLayout(null);
        Toolkit toolkit = Toolkit.getDefaultToolkit();//获得默认的底层控件的基本功能
        Dimension screen = toolkit.getScreenSize();
        int x = (screen.width - 1111) / 2;
        int y = (screen.height - 625) / 2;
        setBounds(x, y, 1111, 625);//设置窗口居中
        view();

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        setVisible(true);
    }
    private void view() {
        this.getContentPane().setBackground(Color.white);
        Color color1 = new Color(231, 252, 243);
        Head head = new Head("");

        add(head);
        JLabel record = new JLabel("交易记录页面");
        record.setForeground(new Color(131, 111, 111));
        record.setFont(new Font("华文宋体", Font.PLAIN, 27));
        record.setBounds(480, 1, 350, 70);
        head.add(record);
        JLabel back = new JLabel("返回个人中心");
        GoCenterEvent goCenterEvent = new GoCenterEvent(back,this);
        back.addMouseListener(goCenterEvent);
        back.setBounds(25, 23, 250, 30);
        back.setForeground(new Color(131, 111, 111));
        back.setFont(new Font("华文宋体", Font.PLAIN, 27));
        head.add(back);//用add(back)不行
        if(myGoods==null){
            showNone();
        }else {
            showMany();
        }
    }
    private void showNone(){

    }
    private void showMany(){
        RecordTable recordTable = new RecordTable(myGoods,name);
        JScrollPane jScrollPane = new JScrollPane(recordTable);
        add(jScrollPane);
        jScrollPane.setBounds(50, 110, 1011, 430);
    }
    public static void main(String[] args){
        TransactionRecord transactionRecord = new TransactionRecord();
    }
}
