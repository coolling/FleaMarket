package client.pages;

import client.component.CarTable;
import client.component.Head;
import client.component.ProductTable;
import client.event.GoCenterEvent;

import javax.swing.*;
import java.awt.*;

public class ShoppingCart  extends JFrame {
    String name[] = {"商品名称","商品件数","商品价格","总计"," ","   "};
    Object myGoods[][] = {{"hhh", "5", "ok", "99", "delete","buy"},
            {"hhh", "5", "ok", "99", "delete","buy"},
            {"hhh", "5", "ok", "99", "delete","buy"},
            {"hhh", "5", "ok", "99", "delete","buy"},
            {"hhh", "5", "ok", "99", "delete","buy"},
            {"hhh", "5", "ok", "99", "delete","buy"},
            {"hhh", "5", "ok", "99", "delete","buy"},
            {"hhh", "5", "ok", "99", "delete","buy"},
            {"hhh", "5", "ok", "99", "delete","buy"},
            {"hhh", "5", "ok", "99", "delete","buy"},
            {"hhh", "5", "ok", "99", "delete","buy"},
            {"hhh", "5", "ok", "99", "delete","buy"},
            {"hhh", "5", "ok", "99", "delete","buy"},
            {"hhh", "5", "ok", "99", "delete","buy"}};
    public ShoppingCart() {
        super();

        setLayout(null);
        Toolkit toolkit = Toolkit.getDefaultToolkit();//获得默认的底层控件的基本功能
        Dimension screen = toolkit.getScreenSize();
        int x = (screen.width - 1111) / 2;
        int y = (screen.height - 625) / 2;
        setBounds(x, y, 1111, 625);//设置窗口居中
        view();

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        setVisible(true);
    }
    private void view() {
        this.getContentPane().setBackground(Color.white);
        Color color1 = new Color(231, 252, 243);
        Head head = new Head("");

        add(head);
        JLabel car = new JLabel("购物车页面");
        car.setForeground(new Color(131, 111, 111));
        car.setFont(new Font("华文宋体", Font.PLAIN, 27));
        car.setBounds(480, 1, 350, 70);
        head.add(car);
        JLabel back = new JLabel("返回个人中心");
        GoCenterEvent goCenterEvent = new GoCenterEvent(back,this);
        back.addMouseListener(goCenterEvent);
        back.setBounds(25, 23, 250, 30);
        back.setForeground(new Color(131, 111, 111));
        back.setFont(new Font("华文宋体", Font.PLAIN, 27));
        head.add(back);//用add(back)不行
        if(myGoods==null){
            showNone();
        }else {
            showMany();
        }
    }
    private void showNone(){

    }
    private void showMany(){
        CarTable productTable = new CarTable(myGoods,name);
        JScrollPane scrollPane = new JScrollPane(productTable);
        scrollPane.setBounds(50, 110, 1011, 430);
        add(scrollPane);
    }
    public static void main(String[] args){
        ShoppingCart shoppingCart = new ShoppingCart();
    }
}

