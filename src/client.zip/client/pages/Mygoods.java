package client.pages;

import client.component.Head;
import client.component.ImagePanel;
import client.component.ProductTable;
import client.event.GoCenterEvent;
import client.json.Product;

import javax.swing.*;
import java.awt.*;

public class Mygoods extends JFrame {
    Object name[] = {"商品名称", "价格", "商品状态", "上架时间", "停售开关"};
    Object myGoods[][] = {{"hhh", "5", "ok", "99", "on"},
            {"hhh", "5", "ok", "99", "on"},
            {"hhh", "5", "ok", "99", "on"},
            {"hhh", "5", "ok", "99", "on"},
            {"hhh", "5", "ok", "99", "on"},
            {"hhh", "5", "ok", "99", "on"},
            {"hhh", "5", "ok", "99", "on"},
            {"hhh", "5", "ok", "99", "on"},
            {"hhh", "5", "ok", "99", "on"},
            {"hhh", "5", "ok", "99", "on"},
            {"hhh", "5", "ok", "99", "on"},
            {"hhh", "5", "ok", "99", "on"},
            {"hhh", "5", "ok", "99", "on"},
            {"hhh", "5", "ok", "99", "on"},
            {"hhh", "5", "ok", "99", "on"},
            {"hhh", "5", "ok", "99", "on"},
            {"hhh", "5", "ok", "99", "on"},
            {"hhh", "5", "ok", "99", "on"},
            {"hhh", "5", "ok", "99", "on"}};
    private Product[] products = {new Product("", "", 1, 1)};

    public Mygoods() {
        super();
        setLayout(null);
        Toolkit toolkit = Toolkit.getDefaultToolkit();//获得默认的底层控件的基本功能
        Dimension screen = toolkit.getScreenSize();
        int x = (screen.width - 1111) / 2;
        int y = (screen.height - 625) / 2;
        setBounds(x, y, 1111, 625);//设置窗口居中
        view();
        if (products.length == 0) {
            noneView();
        } else {
            mangView();
        }
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        setVisible(true);


    }

    private void view() {
        Head head = new Head("我的商品界面");
        add(head);
        this.getContentPane().setBackground(Color.white);
        JLabel back = new JLabel("返回个人中心");
        GoCenterEvent goCenterEvent = new GoCenterEvent(back,this);
        back.addMouseListener(goCenterEvent);
        back.setBounds(25, 23, 250, 30);
        back.setForeground(new Color(131, 111, 111));
        back.setFont(new Font("华文宋体", Font.PLAIN, 27));
        head.add(back);//用add(back)不行

    }

    private void noneView() {
        ImagePanel noneImg = new ImagePanel("/WechatIMG12.jpeg");
        noneImg.setBounds(480, 120, 150, 150);
        this.add(noneImg);
        JLabel none = new JLabel("您暂时没有上架商品呢");
        none.setForeground(new Color(131, 111, 111));
        none.setFont(new Font("华文宋体", Font.PLAIN, 27));
        none.setBounds(420, 300, 400, 70);
        add(none);
        JLabel goUp = new JLabel("去上架");
        goUp.setForeground(new Color(108, 158, 227));
        goUp.setFont(new Font("华文宋体", Font.PLAIN, 27));
        goUp.setBounds(515, 360, 200, 70);
        add(goUp);
    }

    private void mangView() {
        ProductTable productTable = new ProductTable(myGoods, name);
        JScrollPane scrollPane = new JScrollPane(productTable);
        scrollPane.setBounds(50, 110, 1011, 430);
        add(scrollPane);
    }

    public static void main(String[] args) {
        Mygoods mygoods = new Mygoods();
    }
}
