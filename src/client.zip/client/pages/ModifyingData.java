package client.pages;

import client.component.CLabel;
import client.component.Head;
import client.component.ImagePanel;
import client.component.RediusTextField;
import client.event.GoCenterEvent;
import client.event.RegisterEvent;

import javax.swing.*;
import java.awt.*;

public class ModifyingData extends JFrame {
    String telephone = "110";
    String name = "帅大玲";
    String nickname = "哒哒哒哒玲";
    String sex = "女";
    String area = "软件园";
    String grade = "大一";
    String major = "软件工程";
    String headUrl = "/my.png";

    public ModifyingData() {
        super();

        setLayout(null);
        Toolkit toolkit = Toolkit.getDefaultToolkit();//获得默认的底层控件的基本功能
        Dimension screen = toolkit.getScreenSize();
        int x = (screen.width - 1111) / 2;
        int y = (screen.height - 625) / 2;
        setBounds(x, y, 1111, 625);//设置窗口居中
        view();

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        setVisible(true);
    }

    private void view() {
        this.getContentPane().setBackground(Color.white);
        Color color1 = new Color(231, 252, 243);
        Head head = new Head("");

        add(head);
        JLabel edit = new JLabel("修改个人资料");
        edit.setForeground(new Color(131, 111, 111));
        edit.setFont(new Font("华文宋体", Font.PLAIN, 27));
        edit.setBounds(480, 1, 350, 70);
        head.add(edit);
        JLabel back = new JLabel("返回个人中心");
        GoCenterEvent goCenterEvent = new GoCenterEvent(back, this);
        back.addMouseListener(goCenterEvent);
        back.setBounds(25, 23, 250, 30);
        back.setForeground(new Color(131, 111, 111));
        back.setFont(new Font("华文宋体", Font.PLAIN, 27));
        head.add(back);//用add(back)不行
        showData();
    }

    private void showData() {
        CLabel teleLable = new CLabel("联系方式:" );
        CLabel nameLabel = new CLabel("真实姓名：");
        CLabel nickLable = new CLabel("昵称:" );
        CLabel sexLable = new CLabel("性别:" );
        CLabel areaLable = new CLabel("校区:" );
        CLabel gradeLable = new CLabel("年级：" );
        CLabel majorLable = new CLabel("专业：");
        add(teleLable);
        add(nameLabel);
        add(nickLable);
        add(sexLable);
        add(areaLable);
        add(gradeLable);
        add(majorLable);
        teleLable.setBounds(450, 120, 200, 50);
        sexLable.setBounds(230, 180, 150, 50);
        nickLable.setBounds(700, 180, 150, 50);
        areaLable.setBounds(160, 300, 150, 50);
        nameLabel.setBounds(800, 300, 250, 50);
        gradeLable.setBounds(320, 470, 150, 50);
        majorLable.setBounds(600, 480, 150, 50);
        RediusTextField teleField0 = new RediusTextField(20,0,0,"");
        //teleField0.setEnabled(false);
        RediusTextField teleField = new RediusTextField(20,0,0,telephone);
        RediusTextField nameField = new RediusTextField(10,0,0,name);
        RediusTextField nickField = new RediusTextField(10,0,0,nickname);
        RediusTextField sexField = new RediusTextField(3,0,0,sex);
        RediusTextField gradeField = new RediusTextField(10,0,0,grade);
        RediusTextField majorField = new RediusTextField(10,0,0,major);
        RediusTextField areaField = new RediusTextField(10,0,0,area);
        add(teleField0);
        add(teleField);
        add(nameField);
        add(nickField);
        add(sexField);
        add(gradeField);
        add(majorField);
        add(areaField);
        teleField0.setBounds(500, 10, 1, 1);
        teleField.setBounds(580, 120, 200, 50);
        sexField.setBounds(310, 180, 100, 50);
        nickField.setBounds(780, 180, 200, 50);
        areaField.setBounds(240, 300, 200, 50);
        nameField.setBounds(930, 300, 200, 50);
        gradeField.setBounds(400, 470, 200, 50);
        majorField.setBounds(680, 480, 200, 50);
        CLabel head = new CLabel("头像:");
        add(head);
        head.setBounds(530,210,150,50);
        ImagePanel headPanel = new ImagePanel(headUrl);
        headPanel.setBounds(500,265,120,120);
        add(headPanel);
        JButton save = new JButton("save");
        add(save);
        save.setBounds(920,520,80,50);
        save.setForeground(new Color(131, 111, 111));
        save.setFont(new Font("华文宋体", Font.PLAIN, 22));
    }

    public static void main(String[] args) {
        ModifyingData modifyingData = new ModifyingData();
    }
}
