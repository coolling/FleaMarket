package client.json;

public class Product {
    public String image;
    public String detail;
    public double price;
    public int amout;

    public Product(String image, String detail, double price, int amout) {
        this.image = image;
        this.detail = detail;
        this.price = price;
        this.amout = amout;
    }
}
