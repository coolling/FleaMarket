package client.json;

public class Comment {
    public String commentContext;
    public String commentTime;
    public String commentId;
    public String commenter;
    
}
