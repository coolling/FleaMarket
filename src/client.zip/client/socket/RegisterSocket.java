package client.socket;

import client.pages.Index;
import client.pages.Mistake;
import com.alibaba.fastjson.JSONObject;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Scanner;

public class RegisterSocket {
    public static int  registerServe() throws IOException {
        int result=1;
        InetAddress addr = InetAddress.getLocalHost();
        Socket socket = new Socket("127.0.0.1", 2000);
        System.out.print("请求连接");
        try {
            //客户端输出流，向服务器发消息
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            //客户端输入流，接收服务器消息
            BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter pw = new PrintWriter(bw, true); //装饰输出流，及时刷新
            Scanner in = new Scanner(System.in); //接受用户信息
            String msg = null;
            JSONObject registerJoson = new JSONObject();
            //string
            registerJoson.put("userPass","clx0725.");
            //int
            registerJoson.put("userId","201900301133");
            String loginString = registerJoson.toString();
            byte[] jsonByte = loginString.getBytes();
            DataOutputStream outputStream = null;
            outputStream = new DataOutputStream(socket.getOutputStream());
            System.out.println("发的数据长度为:"+jsonByte.length);
            System.out.println(loginString);

            outputStream.write(jsonByte);
            outputStream.flush();
            System.out.println("传输数据完毕");



            while((msg=in.next())!=null){
                JSONObject object = JSONObject
                        .parseObject(msg);
                result =  object.getIntValue("flag");

            }


            socket.shutdownOutput();

            System.out.println(br.readLine()); //输出服务器返回的消息
            pw.close();
            bw.close();
            br.close();
            in.close();

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (null != socket) {
                try {
                    socket.close(); //断开连接
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return result;
    }
}
